#### Software and hardware versions 
Android vx.x.x, device used...

#### Problem description

#### Steps to reproduce the problem

#### Expected behavior

#### Other information 
Things you tried, stack traces, related issues, suggestions on how to fix it...
