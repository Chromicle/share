package org.odk.share.adapters.basecursoradapter;

public interface ItemClickListener {

    void onItemClick(BaseCursorViewHolder holder, int position);
}
