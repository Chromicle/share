package org.odk.share.listeners;

import android.view.View;

/**
 * Created by laksh on 5/23/2018.
 */

public interface OnItemClickListener {
    void onItemClick(View v, int position);
}